
#ifndef menu_h
#define menu_h

#define EVENT_BUTTON         1
#define EVENT_BUTTON_PULSADO 2

char* stMain_Menu[]={
    "Ver Reloj.",
    "Ajustar Hora",
    "Selecionar Alarma",
    "Activar Alarma", 
    "" };

#define MAX_MAIN_MENU        		4

#define MENU_TOP_HORA        		0
#define MENU_TOP_AJUST_HORA 		1
#define MENU_TOP_AJUST_ALARM 		2
#define MENU_TOP_MENU_AJUST_ALARM  	3
#define MENU_TOP_MAIN_MENU   MAX_MAIN_MENU+1

#define BOTON_U 1
#define BOTON_D 2
#define BOTON_L 3
#define BOTON_R 4
#define BOTON_B 5
#define BOTON_A 6

char* stAlarm_Menu[]={
    "Alarma 1",
    "Alarma 2 ",
    "Alarma 3 ",
    "Alarma 4 ",
    "" };

#define MAX_ALARM_MENU        3

typedef struct {
  unsigned char menu_top;
  unsigned char menu_main;
  unsigned char menu_alarm_actu;
  unsigned char event;
  unsigned long next_time; 
  byte actualiza_pantalla;
  boolean on_off;
  tmElements_t  tiempo;
  } stMenu;
  
const int tiempo_max[]={31, 12, 2050, 6, 24, 60, 60};

void showMenu(char* text1, char* text2);

#endif

