/*
Phi-2 shield for Arduino
Program title: Phi clock version 5 
----------------------------------------
Programmed by Dr. John Liu
Revision: 08/26/2012
Free software for educational and personal uses.
No warrantee!
Commercial use without authorization is prohibited.
Find details of the Phi-1 shield, Phi-2 shield, and Phi-prompt or contact Dr. Liu at
http://liudr.wordpress.com/phi-1-shield/
http://liudr.wordpress.com/phi-2-shield/
http://liudr.wordpress.com/phi_interfaces/
http://liudr.wordpress.com/phi_prompt/
All rights reserved.
*/
#ifndef alarm_clock_h
#define alarm_clock_h
#include <arduino.h>

#define Max_alarms 4
#define alarm_EEPROM_storage (1023-3*Max_alarms) // Where the alarm is saved. This is assuming ATMEGA328 is used with 1K EEPROM so the 1023.

class alarm_clock
{
public:
  alarm_clock(boolean noo);
  byte run(); // Returns which alarm is triggered, 0-Max_alarms, 255 means no alarm is triggered.
  byte set_alarm(byte alarm_num, byte hr, byte mnt, byte dow); // Returns 255 if parameters are invalid. Returns 0 if valid.
  void turn_on(byte alarm_num);
  void turn_off(byte alarm_num);
  void alarm();
  boolean within(byte a, byte dow);
  void save_alarm(byte ala); ///< This saves the alarm setting of alarm ala to the ATMEGA328 EEPROM.
  
  typedef struct {
  byte hr;
  byte mnt;
  byte dow;
  boolean on_off; // This variable is not used. Instead dow is used to turn the alarm off or on.
  } entry;

  entry alarms[Max_alarms];
  boolean alarm_is_on; // Alarm is on. alarm() will be called if this is true.
  byte snooze;
};
#endif
