
#ifndef menu_h
#define menu_h

#define EVENT_BUTTON         1
#define EVENT_BUTTON_PULSADO 2
char* stMain_Menu[]={
    "Ver Reloj.",
    "Ajustar Hora",
    "Ajustar Alarma",
    "Activar Alarma", 
    "" };

#define MAX_MAIN_MENU        3

#define MENU_TOP_HORA        0
#define MENU_TOP_AJUST_HORA  1
#define MENU_TOP_AJUST_ALARM 2
#define MENU_TOP_MAIN_MENU   MAX_MAIN_MENU+1

typedef struct {
  unsigned char menu_top;
  unsigned char menu_main;
  unsigned char event;
  unsigned long next_time; 
  byte actualiza_pantalla;
  boolean on_off;
  int  tiempo [8];
  } stMenu;
  
const int tiempo_max[]={31, 12, 2050, 6, 24, 60, 60};
#endif

