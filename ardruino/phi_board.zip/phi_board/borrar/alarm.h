 

#ifndef alarmh_h 
#define alarmh_h 

#define MAX_ALARM 4

// tipos de alarma.

#define DIA 1
#define SEMANA 2

typedef unsigned long time_t;


typedef struct {
  time_t time;
  int type;
  } st_value_alarm;
 
 typedef struct {
  tmElements_t tm;
  int type;
  } st_tmElements_alarm;
   

  
#endif 

