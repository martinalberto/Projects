/*
Phi-1 shield and phi-menu for Arduino
Test program: Phi-menu 323 release for Phi-1 and 2 shields
To choose between phi-1 and phi-2 shields, uncomment line 20 or 21, the corresponding #define such as #define phi_1_shield.
For phi-2 shield, connect the buzzer to analog 2.

Programmed by Dr. John Liu
Revision: 03/19/2011
Free software for educational and personal uses.
No warrantee!
Commercial use without authorization is prohibited.
Find details of the Phi-1 shield, Phi-2 shield or contact Dr. Liu at
http://liudr.wordpress.com/phi-1-shield/
http://liudr.wordpress.com/phi-2-shield/
All rights reserved.

Summary:
This is part of the 323 release of phi-menu for phi-1 shields. Please refer to the ducomentation phi-menu_20110312.pdf at http://liudr.wordpress.com/phi-menu.

*/

#ifndef phi_buttons_h
#define phi_buttons_h
#include <Arduino.h>

#define buttons_up 0 // no-transitional
//#define buttons_pressed 1 // transitional, no longer in use
#define buttons_down 2 // no-transitional
#define buttons_held 3
#define buttons_released 4
#define buttons_debounce 5 // One needs to wait till debounce is over to become pressed.
#define buttons_hold_time 1000
#define buttons_debounce_time 50
#define buttons_dash_threshold 10
#define buttons_repeat_time 250
#define buttons_dash_time 50
#define buttons_disabled 99
#define btn_auto 254 //Auto buttons are attached to pin 254
#define btn_null 255 //Null buttons are attached to pin 255
#define auto_ratio 5 // Auto button is pressed every auto_ratio*repeat_time, so 1.25s.

class phi_buttons
{
  public:
  byte stat;
  byte pin;
  byte pressed; // Polarity of buttons. For those with push-up resistors enabled, button pressed corresponds to low so this is LOW. 
  byte counts;
  boolean holding;
  unsigned long t_down;
  static unsigned long t_last_action; // This stores the last time any real button was active. You may use this to implement sleeping mode.
  byte sense();
  void do_up();
  void do_debounce();
  void do_down();
  void do_released();
  void do_held();
  phi_buttons(byte p);
  phi_buttons(byte p, byte pd);
};
#endif
// pressed=HIGH means pressing buttons gives HIGH. A pull-down resistor is needed. pressed=LOW means pressing buttons gives LOW. One can use the internal pull-up resistor.
