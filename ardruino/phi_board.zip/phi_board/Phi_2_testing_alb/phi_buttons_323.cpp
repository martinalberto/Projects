/*
Phi-1 shield and phi-menu for Arduino
Test program: Phi-menu 323 release for Phi-1 and 2 shields
To choose between phi-1 and phi-2 shields, uncomment line 20 or 21, the corresponding #define such as #define phi_1_shield.
For phi-2 shield, connect the buzzer to analog 2.

Programmed by Dr. John Liu
Revision: 03/19/2011
Free software for educational and personal uses.
No warrantee!
Commercial use without authorization is prohibited.
Find details of the Phi-1 shield, Phi-2 shield or contact Dr. Liu at
http://liudr.wordpress.com/phi-1-shield/
http://liudr.wordpress.com/phi-2-shield/
All rights reserved.

Summary:
This is part of the 323 release of phi-menu for phi-1 shields. Please refer to the ducomentation phi-menu_20110312.pdf at http://liudr.wordpress.com/phi-menu.

*/

#include "phi_buttons_323.h"
unsigned long phi_buttons::t_last_action=0;

phi_buttons::phi_buttons(byte p, byte pd)
// A 255 on p means the button is null. A null button always returns buttons_up. This way one can create all the null buttons in case only say 3 buttons are needed. None of the sensing programs need to be changed with the help of null buttons.
// Not implemented: A 254 on p means the button is auto. An auto button will periodically return buttons_held and buttons_released.
{
  pressed=pd;
  pin=p;
  stat=buttons_up;
  counts=0;
  holding=false;
  t_last_action=millis();
  switch(p)
  {
    case btn_null:
    break;
    
    case btn_auto:
    t_down=millis();
    break;

    default:
    pinMode(p, INPUT);
    digitalWrite(p, HIGH);
    break;
  }
}

byte phi_buttons::sense()
{
  if (millis()<t_last_action) t_last_action=0;
  // Treating special buttons: null and auto buttons
  switch(pin)
  {
    case btn_null:
    stat=buttons_up; // Null buttons are always in buttons_up status.
    return stat;
    break;
    
    case btn_auto:
    if (millis()<t_down) t_down=0;
    if (t_down<t_last_action) t_down=t_last_action; // Make sure if a real button is pressed, the auto button is reset and will wait for a full period. So if you hang on to a real button, the auto button is not going to start clicking until you let go the real button.
    if ((millis()-t_down)>auto_ratio*buttons_repeat_time)
    {
      t_down=millis();
      stat=buttons_released;
    }
    else
    {
      stat=buttons_down;
    }
    return stat;
    break;

    default:
    break;
  }
  
  switch(stat)
  {
    case buttons_up:
    do_up();
    break;
    
    case buttons_debounce:
    do_debounce();
    break;
    
    case buttons_down:
    do_down();
    break;
    
    case buttons_held:
    do_held();
    break;
    
    case buttons_released:
    do_released();
    break;
    
    default:
    break;
  }
  return stat;
}

void phi_buttons::do_up()
{
  holding=false;
  counts=0;
  if (digitalRead(pin)==pressed)
  {
    stat=buttons_debounce;
    t_down=millis();
    t_last_action=t_down;
  }
}

void phi_buttons::do_debounce()
{
  if (digitalRead(pin)==pressed)
  {
    if ((millis()-t_down)>buttons_debounce_time) stat=buttons_down;
  }
  
  else stat=buttons_up;
}

void phi_buttons::do_down()
{
  int thre;
  if (digitalRead(pin)!=pressed)
  {
    stat=holding?buttons_up:buttons_released;
    t_last_action=millis();
  }
  else
  {
    if (holding)
    {
      if (counts>buttons_dash_threshold) thre=buttons_dash_time;
      else thre=buttons_repeat_time;
    }
    else thre=buttons_hold_time;
    
    
    if (millis()-t_down>thre)
    {
      stat=buttons_held;
      t_last_action=millis();
      if (counts<=buttons_dash_threshold) counts++;
    }
    else
    {
      stat=buttons_down;
      t_last_action=millis();
    }
  }
}

void phi_buttons::do_released()
{
  stat=buttons_up;
  t_last_action=millis();
  holding=false;
  counts=0;
}

void phi_buttons::do_held()
{
  holding=true;
  if (digitalRead(pin)==pressed)
  {
    stat=buttons_down;
    t_down=millis();
    t_last_action=t_down;
  }
  else
  {
    stat=buttons_released;
    t_last_action=millis();
  }
}

