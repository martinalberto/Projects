// 7 seg
const int sevenSeg[17] = {
 0x11, // 0 dec 0001 0001 bin
 0xD7, // 1 dec 1101 0111 bin
 0x32, // 2 dec 0011 0010 bin
 0x92, // 3 dec 1001 0010 bin
 0xD4, // 4 dec 1101 0100 bin
 0x98, // 5 dec 1001 1000 bin
 0x18, // 6 dec 0001 1000 bin
 0xD3, // 7 dec 1101 0011 bin
 0x10, // 8 dec 0001 0000 bin
 0x90, // 9 dec 1001 0000 bin
 0x50, // "A" dec 0101 0000 bin
 0x1C, // "b" dec 0001 1100 bin
 0x39, // "C" dec 0011 1001 bin
 0x16, // "d" dec 0001 0110 bin
 0x38, // "E" dec 0011 1000 bin
 0x78, // "F" dec 0111 1000 bin
 0xEF  // . dec 1110 1111 bin
};